<!DOCTYPE html>
<html lang="en">
<body>
<div class="active pageWrapper" id="wrapper">
    <div class="mainContent">
      <div class="container-fluid">
          <div class="pagecontentWrap">
              <div class="toggleButtonWrap">
                <button class="btn btn-primary" id="menu-toggle"><span class="flaticon-menu"></span></button>
              </div>
              <div class="row">
                <div class="col-md-12">
                    <div class="studentResultdtl">
                        <div class="row">
                          <div class="col-md-7">
                              <div class="dataWrap">
                                <h2>Congratulations, <?php $studentid = $this->session->userdata('studentid');  echo $session_name = $this->session->userdata('first_name');  ?></h2>
                                <p class="clrTxt">Know Your Result</p>
                              </div>
                          </div>
                          <div class="col-md-2">
                              <div class="quizIcoWrap">
                                <img src="<?php echo base_url();?>assets/img/quiz-img3.png" alt="DMSF" class="img-fluid"/>
                              </div>
                          </div>
                          <div class="col-md-3">
                            <div class="imgWrap">
                              <img src="<?php echo base_url();?>assets/img/welcome-bg.png" alt="DMSF" class="img-fluid"/>
                            </div>
                          </div>
                        </div>
                        <div class="row justify-content-between align-items-center">
                            <div class="col-md-6">
                                <div class="row justify-content-between">
                                    <div class="col-md-5">
                                        <div class="resultGraphWrap">
                                          <div class="icoWrap">
                                              <img src="<?php echo base_url();?>assets/img/ico-check-1.png" alt="DMSF" class="img-fluid"/>
                                          </div>
                                          <div class="dataWrap">
                                              <h2><?php  $totalPercentage = ($resultofStudentAnsweredCorrectly / $totalMarks[0]['number_of_questions']) * 100 ;
                                                echo ceil($totalPercentage).'%';
                                               ?></h2>
                                               <span id="ceilamount" style="display:none;"><?php echo ceil($totalPercentage); ?></span>
                                              <p>Number of Questions <br/> Answered Correctly</p>
                                          </div>

                                          <div class="pie">
                                            <div class="pie__container">
                                              <div class="pie__container--chart"></div>
                                            </div>
                                          </div>
                                        </div>
                                    </div>


                                    <div class="col-md-5">
                                        <div class="resultGraphWrap">
                                          <div class="icoWrap">
                                              <img src="<?php echo base_url();?>assets/img/ico-check-2.png" alt="DMSF" class="img-fluid"/>
                                          </div>
                                          <div class="dataWrap">
                                         <h2><?php  $totalPercentage = ($resultofStudentAnsweredInCorrectly / $totalMarks[0]['number_of_questions']) * 100 ;
                                                echo ceil($totalPercentage).'%';
                                               ?></h2>
                                               <span id="ceilamount2" style="display:none;"><?php echo ceil($totalPercentage); ?></span>
                                              <p>Number of Questions <br/> Answered In Correctly</p>
                                          </div>
                                          <div class="pie">
                                            <div class="pie__container">
                                              <div class="pie__container--chart pie__container--chart1"></div>
                                            </div>
                                          </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                  <div class="col-md-12">
                                    <div class="bottomTxt">
                                      <h2>Bravo....!!!!!</h2>
                                    </div>
                                  </div>
                                </div>
                            </div>
                            <div class="col-md-5">
                              <div class="scorelistWrap">
                                <ul class="scoreList">
                                    <li>
                                      <span><?php echo $totalMarks[0]['number_of_questions'] ;?></span>
                                      <p>Total Number of
                                        Questions</p>
                                    </li>
                                    <li>
                                      <span><?php echo $resultofStudentAnsweredCorrectly;?></span>
                                      <p>Answered Correctly</p>
                                    </li>
                                    <li>
                                      <span><?php echo $resultofStudentAnsweredInCorrectly; ?></span>
                                      <p>Answered Incorrectly</p>
                                    </li>
                                    <li>
                                      <span><?php echo $resultofStudentUnAnswered; ?></span>
                                      <p>Unanswered Questions</p>
                                    </li>
                                </ul>
                              </div>
                            </div>
                        </div>
                    </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-7">
                    <div class="toppersWrap">
                      <h2>Last Week Topppers</h2>
                      <ul class="tooperListing">
                          <li>
                            <div class="imgWrap">
                                <img src="<?php echo base_url();?>assets/img/img-1.png" class="img-fluid" alt="DMSF"/>
                                <div class="badgeIoc">
                                    <img src="<?php echo base_url();?>assets/img/badge-img-1.png" alt="DMSF" class="img-fluid"/>
                                </div>
                            </div>
                            <div class="dataWrap">
                                <h2>Elena</h2>
                                <p>80%</p>
                            </div>
                          </li>
                          <li>
                            <div class="imgWrap">
                                <img src="assets/img/img-2.png" class="img-fluid" alt="DMSF"/>
                                <div class="badgeIoc">
                                  <img src="<?php echo base_url();?>assets/img/badge-img-2.png" alt="DMSF" class="img-fluid"/>
                                </div>
                            </div>
                            <div class="dataWrap">
                                <h2>paul</h2>
                                <p>80%</p>
                            </div>
                          </li>
                          <li>
                            <div class="imgWrap">
                                <img src="<?php echo base_url();?>assets/img/img-3.png" class="img-fluid" alt="DMSF"/>
                                <div class="badgeIoc">
                                    <img src="<?php echo base_url();?>assets/img/badge-img-3.png" alt="DMSF" class="img-fluid"/>
                                </div>
                            </div>
                            <div class="dataWrap">
                                <h2>Daniel</h2>
                                <p>80%</p>
                            </div>
                          </li>
                          <li>
                            <div class="imgWrap">
                                <img src="assets/img/img-1.png" class="img-fluid" alt="DMSF"/>
                                <div class="badgeIoc">
                                    <img src="<?php echo base_url();?>assets/img/badge-img-1.png" alt="DMSF" class="img-fluid"/>
                                </div>
                            </div>
                            <div class="dataWrap">
                                <h2>Elena</h2>
                                <p>80%</p>
                            </div>
                          </li>
                      </ul>
                    </div>
                </div>
                <div class="col-md-5">
                    <div class="badgesWrapper">
                        <ul>
                            <li>
                                <img src="<?php echo base_url();?>assets/img/badge-img-1.png" alt="DMSF" class="img-fluid"/>
                            </li>
                            <li>
                                <img src="<?php echo base_url();?>assets/img/badge-img-1.png" alt="DMSF" class="img-fluid"/>
                            </li>
                            <li>
                                <img src="<?php echo base_url();?>assets/img/badge-img-1.png" alt="DMSF" class="img-fluid"/>
                            </li>
                            <li>
                                <img src="<?php echo base_url();?>assets/img/badge-img-2.png" alt="DMSF" class="img-fluid"/>
                            </li>
                            <li>
                                <img src="<?php echo base_url();?>assets/img/badge-img-1.png" alt="DMSF" class="img-fluid"/>
                            </li>
                        </ul>
                        <button type="button" class="btn">Get your badge</button>
                    </div>
                </div>
              </div>
          </div>
      </div>
    </div>
  </div>

  <script src="<?php echo base_url();?>assets/js/jquery-1.12.4.min.js"></script>
  <script src="<?php echo base_url();?>assets/js/popper.min.js"></script>
  <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
  <script src="<?php echo base_url();?>assets/js/slick.min.js"></script>
  <script src="<?php echo base_url();?>assets/js/main.js"></script>
  <script>
    $("#menu-toggle").click(function(e) {
      e.preventDefault();
      $("#wrapper").toggleClass("active");
    });
  </script>
  <script>
    var chart ='<svg viewBox="0 0 32 32"><circle class="circle" r="16" cx="16" cy="16" style="stroke-dasharray:0 100" /></svg>';
    $('.pie__container--chart').html(chart);
    
    var chart = $('.pie__container--chart circle');
    var amount1  = $('#ceilamount').text();
    setTimeout(function () { 
      chart.css('stroke-dasharray', 100+ ' 100');
    }, 500);

    var charts ='<svg viewBox="0 0 32 32"><circle class="circle" r="16" cx="16" cy="16" style="stroke-dasharray:0 100" /></svg>';
    $('.pie__container--chart1').html(charts);
    var amount =$('#ceilamount2').text();
    console.log(amount);
    var charts = $('.pie__container--chart1 circle');
    console.log
    setTimeout(function () { 
      charts.css('stroke-dasharray',  0+' 100');
    }, 500);
  </script>

</body>

</html>
