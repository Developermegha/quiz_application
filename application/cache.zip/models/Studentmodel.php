<?php 
class Studentmodel extends CI_Model{
    
    /*
    * get student attempted quiz count
    */
    public function getStudentAttemtedQuiz(){
        
    }
    
    /*
    *
    */
    public function getActiveQuizList(){
        
        $date = date("Y-m-d H:i");
        $beforestart = strtotime($date) + 1200;
        $date = date("Y-m-d H:i:s", $beforestart);
        
        $response = array();
        $this->db->select('qm.*,qt.quiztype,c.course_name,t.topic_name');
        $this->db->from('quiz_master as qm');
        $this->db->join('course as c','c.id = qm.course_id','LEFT');
        $this->db->join('quiz_type as qt','qt.id = qm.type_id','LEFT');
        $this->db->join('topics as t','t.id = qm.topic_id AND t.is_deleted = 0 AND t.active =1','LEFT');
      
        $this->db->where('qm.active',1);
        $this->db->where('qm.is_deleted',0);
        $this->db->where('qm.quiz_start_time <=',$date);
        $this->db->where('qm.quiz_end_time >=',$date);
        $query = $this->db->get();
        // echo $this->db->last_query();
        if($query->num_rows() > 0){
            $response = $query->result();
        }
        return $response;
    }
    
    /*
    */
    public function getAttemptedStudentCount(){
        $this->db->select('count(attempts) as totalattempts');
        $this->db->from('student_quiz_result');
        $query = $this->db->get();
        if($query->num_rows() > 0){
            $response = $query->row()->totalattempts;
        }
        return $response;
        
    }
    
    /*
    * get total active quiz count
    */
    public function getTotalActiveQuizCount(){
        
        $this->db->select('count(id) as totalactive');
        $this->db->from('quiz_master');
        $this->db->where('active',1);
        $this->db->where('is_deleted',0);
        $query = $this->db->get();
        if($query->num_rows() > 0 ){
            $response = $query->row()->totalactive;
        }
        return $response;
    }
    
    /*
    * get total quiz count
    */
    public function getQuizCount(){
         $this->db->select('count(id) as totalQuiz');
        $this->db->from('quiz_master');
        $this->db->where('is_deleted',0);
        $query = $this->db->get();
        if($query->num_rows() > 0 ){
            $response = $query->row()->totalQuiz;
        }
        return $response;
    }
    
    /*
    * studnet not attempted quiz count
    */
    public function getNotAttemptedQuiz(){
        
    }
    
    /*
    * this function get student data
    */
    public function getStudentDetails($id){
        $response = array();
        if(!empty($id)){
            $this->db->select('*');
            $this->db->from('user');
            $this->db->where('is_active',1);
            $this->db->where('is_deleted',0);
            
            $this->db->where('id',$id);
            $query = $this->db->get();
            // echo $this->db->last_query();
            if($query->num_rows() > 0 ){
                $response = $query->row();
            }
        }
        return $response;
    }
    
    /*
    * insert the new student details in db
    */
    public function addNewStudent($data){
        $response = false;
        if(!empty($data)){
            $this->db->insert('user',$data);
            if($this->db->affected_rows() > 0 ){
                $response = true;
            }
        }
        return $response;
    }
    
    /*
    * check the otp enter by student is exits
    * or not in db
    */
    public function check_otp_exists($mobile, $otp ) {
        // this is 20 min ago time
        // $minute_ago = date("Y-m-d H:i:s", mktime(date("H"), date("i") - 20, date("s"), date("m"), date("d"), date("Y")));
        $this->db->select('registration_otp.otp');
        $this->db->from('registration_otp');
        $this->db->where('registration_otp.mobile', $mobile);
        $this->db->where('registration_otp.otp', $otp);
        // $this->db->where('registration_otp.created_at >=',  $minute_ago);
        $this->db->order_by('registration_otp.id',"desc");
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return true;
        } else {
            return false;
        }
    }

    /*
    * check the duplicate record of username
    */
     public function check_user_name_exists($user_name) {
        $this->db->select('id');
        $this->db->from('user');
        $this->db->where('user_name', $user_name);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return false;
        } else {
            return true;
        }
    }


    /*
    */
    public function send_sms_otp($mobile_number, $otp) {
        $data = array('mobile' =>(int) $mobile_number, 'otp' => $otp);
        $insert_registration_otp = $this->db->insert('registration_otp', $data);
        $insert_id = $this->db->insert_id();
        return $insert_id;
    }
    
    /*
    * check for the dublicate record of email
    */
    public function check_email_exists($email) {
        $this->db->select('id');
        $this->db->from('user');
        $this->db->where('email', $email);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return false;
        } else {
            return true;
        }
    }
    
    /*
    */
    public function getActiveQuiz(){
        $response = array();
        $this->db->select('qm.*,qt.quiztype,c.course_name,t.topic_name');
        $this->db->from('quiz_master as qm');
        $this->db->join('course as c','c.id = qm.course_id','LEFT');
        $this->db->join('quiz_type as qt','qt.id = qm.type_id','LEFT');
        $this->db->join('topics as t','t.id = qm.topic_id AND t.is_deleted = 0 AND t.active =1','LEFT');
        $this->db->where('qm.active',1);
        $this->db->where('qm.is_deleted',0);
        $query = $this->db->get();
        if($query->num_rows() > 0){
            $response = $query->result();
        }
        return $response;
        
    }
    
       /*
   * update data of student by id
   */
   public function updateStudentData($data,$id){
       $response = false;
       if(!empty($data) && !empty($id)){
           $this->db->set($data);
           $this->db->where('id',$id);
           $this->db->update('user');
           if($this->db->affected_rows() > 0){
               $response = true;
           }
       }
       return $response;
   }


    /*
    * get the quiz by id
    */
    public function getQuizByid($id)
    {
        $response = array();
        if(!empty($id)){
            $this->db->select('*');
            $this->db->from('quiz_master');
            $this->db->where('id',$id);
            $query = $this->db->get();
            if($query->num_rows() > 0){
                $response = $query->row();
            }
        }
        return $response;
    }
    
    /*
    * change password
    */
    public function updatepassword($id,$password){
        $response = false;
        if(!empty($id) && !empty($password)){
            $this->db->set('password',$password);
            $this->db->where('id',$id);
            $this->db->where('is_active',1);
            $this->db->update('user');
            if($this->db->affected_rows() >0){
                $response  =true;
            }
        }
        return $response;
    }
    
    
    /*
    *
    */
    public function getQuizResultById($id,$quizId){
        $result = array();
        if(!empty($id)){
            $this->db->select('*');
            $this->db->from('quiz');
            $this->db->where('student_id',$id);
            $this->db->where('quiz_id',$quizId);
            $query  = $this->db->get();
            if($query->num_rows() >0){
                $result = $query->row();
            }
        }
        return $result;
    }
    
    
    /*
    * get attempt count of student
    */
    public function getStudentAttemptsCount($quiz_id,$student_id){
        $response =0;
        if(!empty($quiz_id) && !empty($student_id)){
            $this->db->select('attempts');
            $this->db->from('student_quiz_result');
            $this->db->where('quiz_id',$quiz_id);
            $this->db->where('student_id',$student_id);
            $query = $this->db->get();
            if($query->num_rows() >0){
                $response = $query->row()->attempts;
            }
            return $response;
        }
    }
    
    /*
    * insert the result of quiz by studenttid
    */
    
    public function insertQuizResult($data)
    {
        $response = false;
        if(!empty($data)){
            $this->db->insert('student_quiz_result',$data);
            if($this->db->affected_rows() > 0){
                $response = true;
            }
        }
        return $response;
    }
    
    /*
    *
    */
    
    
    
    /* copy paste*/
    
        
    public function student_insert_question($data, $total_number_of_question)
    {
            //echo "<pre>";print_r($data);"</pre>";die;
                    
           $insertStudent          =  $this->db->insert('quiz', $data);
           $insert_id              = $this->db->insert_id();
           return                    $insert_id;
            // $this->db->select('*');
            // $this->db->from('quiz');
            // $this->db->where('student_id', $data['student_id']); 
            // $this->db->where('quiz_id', $data['quiz_id']);  
            // $query = $this->db->get(); 
            // return  $query->result_array();  
              
            
    }
    
    
    public function get_question_redirect( $questionId , $quizId, $submitedAnswer ,$pageId,$quizPrimaryId ){
            $StudentSessionId         = $this->session->userdata['id'];   
            $offset = ( $pageId - 1) * 1;
          
            
            $this->db->select('questionset.* , quiz.id as quizprimaryId,quiz.selected_answer,quiz.mark_for_review');
            $this->db->from('questionset', 'quiz');
            $this->db->join('quiz', 'quiz.q_id = questionset.id');
            $this->db->where('student_id', $StudentSessionId);
            $this->db->limit(1, $offset);
            $query = $this->db->get();  
            return  $query->result_array(); 
    
    }


    
    public function get_question_next($questionId , $quizId, $submitedAnswer, $pageId , $quizPrimaryId ){
    
    //echo "<pre>";print_r($quizPrimaryId);"</pre>";die;
    
       $offset = ( $pageId - 1) * 1;
       $StudentSessionId         = $this->session->userdata['id'];     
      
      if( $submitedAnswer == ""){
           $this->db->where('id', $quizPrimaryId);
           $this->db->where('quiz_id', $quizId);
           $this->db->where('student_id', $StudentSessionId);
           $this->db->set('selected_answer', '');
           $this->db->set('questions_status_id', 6);
           $this->db->update('quiz');  
       }
    
    
       $this->db->select('questionset.* , quiz.id as quizprimaryId,quiz.selected_answer,quiz.mark_for_review');
       $this->db->from('questionset', 'quiz');
       $this->db->join('quiz', 'quiz.quiz_id = questionset.quiz_id');
       $this->db->where('student_id', $StudentSessionId);
    //   $this->db->where_not_in('questionset.id',$questionId);
       $this->db->where('questionset.quiz_id',$quizId);
       
       $this->db->limit(1, $offset);
       $query = $this->db->get(); 
        // echo $this->db->last_query();
       return  $query->result_array();  
    
    }
    
    
    public function get_question_prev($questionId , $quizId, $submitedAnswer,$pageId, $quizPrimaryId){
    
        $offset = ( $pageId - 1) * 1;
        $StudentSessionId         = $this->session->userdata['id'];   
    
       if( $submitedAnswer == ""){
           $this->db->where('id', $quizPrimaryId);
           $this->db->where('quiz_id', $quizId);
           $this->db->where('student_id', $StudentSessionId);
           $this->db->set('selected_answer', '');
           $this->db->set('questions_status_id', 6);
           $this->db->update('quiz');  
       }
       
       $this->db->select('questionset.* , quiz.id as quizprimaryId,quiz.selected_answer,quiz.mark_for_review');
       $this->db->from('questionset', 'quiz');
       $this->db->join('quiz', 'quiz.qset_id = questionset.id');
       $this->db->where('student_id', $StudentSessionId);
       $this->db->limit(1, $offset);
       $query = $this->db->get();  
       return  $query->result_array(); 
    
    }
    
    
    
    public function get_question_review( $questionId , $quizId, $submitedAnswer,$pageId, $quizPrimaryId ){
        $StudentSessionId         = $this->session->userdata['id'];     
        $offset = ( $pageId - 1) * 1;
        $StudentSessionId         = $this->session->userdata['id'];   
    
       if( $submitedAnswer != ""){
           $this->db->where('id', $quizPrimaryId);
           $this->db->where('quiz_id', $quizId);
           $this->db->where('student_id', $StudentSessionId);
           $this->db->set('mark_for_review', 8);
           $this->db->update('quiz');     
       }else{
           $this->db->where('id', $quizPrimaryId);
           $this->db->where('quiz_id', $quizId);
           $this->db->where('student_id', $StudentSessionId);
           $this->db->set('selected_answer', '');
           $this->db->set('mark_for_review', 8);
           $this->db->update('quiz');  
       }
    
    
       $this->db->select('questionset.* , quiz.id as quizprimaryId,quiz.selected_answer,quiz.mark_for_review');
       $this->db->from('questionset', 'quiz');
       $this->db->join('quiz', 'quiz.q_id = questionset.id');
       $this->db->where('student_id', $StudentSessionId);
       $this->db->limit(1, $offset);
       $query = $this->db->get();  
       return  $query->result_array();
    
    }

    public function get_question_unreview( $questionId , $quizId, $submitedAnswer,$pageId, $quizPrimaryId ){
    
        $StudentSessionId         = $this->session->userdata['id'];     
    
        $offset = ( $pageId - 1) * 1;
        $StudentSessionId         = $this->session->userdata['id'];   
    
       if( $submitedAnswer != ""){
           $this->db->where('id', $quizPrimaryId);
           $this->db->where('quiz_id', $quizId);
           $this->db->where('student_id', $StudentSessionId);
           $this->db->set('mark_for_review', '');
           $this->db->update('quiz');     
       }else{
           $this->db->where('id', $quizPrimaryId);
           $this->db->where('quiz_id', $quizId);
           $this->db->where('student_id', $StudentSessionId);
           $this->db->set('selected_answer', '');
           $this->db->set('mark_for_review', '');
           $this->db->update('quiz');  
       }
    
    
       $this->db->select('questionset.* , quiz.id as quizprimaryId,quiz.selected_answer,quiz.mark_for_review');
       $this->db->from('questionset', 'quiz');
       $this->db->join('quiz', 'quiz.q_id = questionset.id');
       $this->db->where('student_id', $StudentSessionId);
       $this->db->limit(1, $offset);
       $query = $this->db->get();  
       return  $query->result_array();
    }
    
    /*
    * get the details of quiz id
    */   
    public function updateQuestionPalletStatus($quizPrimaryId){

        $this->db->select('id,questions_status_id,mark_for_review');
        $this->db->from('quiz');
        $this->db->where('id', $quizPrimaryId);  
        $query = $this->db->get();

        return  $query->result_array(); 
    }

    public function submit_answer_of_student( $pageId, $quizId, $submitedAnswer, $questionId ){
        $StudentSessionId         = $this->session->userdata['id'];
       // $offset = ( $pageId - 1) * 1; 
       // echo "<pre>";print_r($offset);"</pre>";die;

        if( $submitedAnswer == ""){
            $this->db->where('qset_id', $questionId);
            $this->db->where('quiz_id', $quizId);
            $this->db->set('selected_answer', '');
            $this->db->set('questions_status_id', 6);
            $this->db->update('quiz'); 

        }

        $this->db->select('questionset.* , quiz.id as quizprimaryId,quiz.selected_answer,quiz.mark_for_review');
        $this->db->from('questionset', 'quiz');
        $this->db->join('quiz', 'quiz.qset_id = questionset.id');
        $this->db->where('student_id', $StudentSessionId);
        $this->db->where('questions_status_id', 7);
        $this->db->where('questions_status_id', 9);
        $this->db->limit(1,$pageId);
        $query = $this->db->get(); 
       // echo "<pre>";print_r($this->db->last_query());"</pre>";die;
        if($query->num_rows() > 0 ){
            return  true;    
        }else{
            return true;
        }
    }


    public function countPendingAnswer($quizId){
        
        $data = array();
        $StudentSessionId         = $this->session->userdata['id'];
        
        $this->db->select('COUNT(questions_status_id) As questions_status');
        $this->db->from('quiz');
        $this->db->where('student_id', $StudentSessionId); 
        $this->db->where('quiz_id', $quizId); 
        $this->db->where('questions_status_id', 6); 
        $query = $this->db->get(); 
        $data['not_answered']  = $query->result_array();
        
        $this->db->select('COUNT(questions_status_id) As un_answered');
        $this->db->from('quiz');
        $this->db->where('student_id', $StudentSessionId); 
        $this->db->where('quiz_id', $quizId); 
        $this->db->where('questions_status_id', 7); 
        $query = $this->db->get(); 
        $data['un_answered']  = $query->result_array(); 
        
        $this->db->select('COUNT(questions_status_id) As correct_answered');
        $this->db->from('quiz');
        $this->db->where('student_id', $StudentSessionId); 
        $this->db->where('quiz_id', $quizId); 
        $this->db->where('questions_status_id', 5); 
        $query = $this->db->get(); 
        $data['correct_answered']  = $query->result_array(); 
        // echo $this->db->last_query();die;
        
        
        $this->db->select('COUNT(mark_for_review) As mark_for_review_question');
        $this->db->from('quiz');
        $this->db->where('student_id',$StudentSessionId); 
        $this->db->where('quiz_id', $quizId); 
        $this->db->where('mark_for_review', 8); 
        $query = $this->db->get(); 
        $data['mark_for_review']  = $query->result_array(); 
        
        return $data;
        
        
        }
        
     
}
?>