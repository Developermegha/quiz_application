<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Student extends CI_Controller {
    
    var $view_path = 'student/';
    var $action = 'student/';
    
    public function __construct(){
        parent::__construct();
        $this->load->model('Studentmodel','studentmodel');
           $this->load->model('Adminmodel','Adminmodel');
    }
  
    /*
    * student dashboard
    */
    public function index(){
        
        $this->load->view('login');
    }
    
     /*
    * register students
    */
    public function register_student(){
        
        $firstname = $this->input->post('first_name');
        $lastname = $this->input->post('last_name');
        $username = $this->input->post('user_name');
        $email = $this->input->post('email');
        $mobile = $this->input->post('mobile');
        $otp = $this->input->post('otp');
        $password = $this->input->post('password');
        $retype_password = $this->input->post('retype_password');
        
        if(empty($email)  || empty($password) || empty($username) || empty($retype_password) || empty($firstname)  || empty($username)  ){
            $this->response['code'] = RES_MISSING;
            $this->response['msg'] = 'Parameter missing or invalid url';
            echo json_encode($this->response);
            return false;
            
        }
        
        if($password != $retype_password  ){
            $this->response['code'] = RES_MISSING;
            $this->response['msg'] = 'Not match the password enter';
            echo json_encode($this->response);
            return false;
            
        }
        
        $dataAr = array(
            'user_name' => $username,
            'first_name' => $firstname,
            'last_name' => $lastname,
            'mobile' => $mobile,
            'email' => $email,
            'password' => encrypt_script($password),
            'is_active' => 1,
            'created_at' => date('Y-m-d H:i:s'),
            
        
        );
        
        $result = $this->studentmodel->addNewStudent($dataAr);
        if($result){
            $this->response['code']  = RES_SUCCESS;
            $this->response['msg'] = 'Added Successfully!';
            echo json_encode($this->response);
        }else{
            $this->response['code']  = RES_MISSING;
            $this->response['msg'] = 'Not Added Successfully!';
            echo json_encode($this->response);
        }
      
        
    }
    
    
    /*
    * student register
    */
    public function register(){
        $this->load->view('student_register');
    }
  
      
    /*
    * student dashboard
    */
    public function dashboard(){
        
        if($_SESSION['is_student_loggedin'] == true){
            
	        $data['activeCount'] = $this->studentmodel->getTotalActiveQuizCount();
	        $data['allQuizs'] = $this->studentmodel->getQuizCount();
	        $data['activeQuiz'] = $this->studentmodel->getActiveQuizList();
	        $data['attemtedStudentCount'] = $this->studentmodel->getAttemptedStudentCount();
	       // $data['studentappliedquizmarks'] = $this->studentmodel->getStudentquizresult();
	        $this->load->back_template($this->view_path."dashboard",$data);
	        
	    }else{
	        redirect('student/login');
	    }
    }
    
       	public function getTopicList()
    {
        
            $topic=$this->input->post('att_type');
            $course=$this->input->post('sub');
            $res= $this->AdminModel->fetchtopics($topic,$course);
            echo json_encode($res);
        
    }
    
    /*
    * edit student profile
    */
    public function editProfile(){
        
        $studentId = getSessionData('id');
        $data['studentAr'] = $this->studentmodel->getStudentDetails($studentId) ;
        
        $this->load->back_template($this->view_path."profile",$data);
    }
    
    /*
    * send sms of otp to the mobile 
    */
    public function sendSmsOtp(){
        
           $apikey = "NjtxLSp4y0yXpWDCLukERA";
        $apisender = "TRAEDU";
        $otp = rand(1000, 9999);
        $for = "registration";
        $msg = "Your login otp for $for is $otp.

        Thank you for choosing Transworld Educare.";
        $mobile_number = $this->input->post('mobile_number');
        $send_sms_otp_result = $this->studentmodel->send_sms_otp($mobile_number, $otp);
        $num = "91".$mobile_number; // MULTIPLE NUMBER VARIABLE PUT HERE...!
        $ms = rawurlencode($msg); //This for encode your message content
        $url = 'https://www.smsgatewayhub.com/api/mt/SendSMS?APIKey=' . $apikey . '&senderid=' . $apisender . '&channel=2&DCS=0&flashsms=0&number=' . $num . '&text=' . $ms . '&route=1';
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, "");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 2);
        $data = curl_exec($ch);
        /* result of API call*/
        $data = json_decode($data, TRUE);
        if ($data['ErrorMessage'] == "Success") {
            $result = true;
        } else {
            // $result['message'] = "Fail";
            $result = false;
        }
        echo json_encode($result);
        die;  
        
    }
    
    /*
    * verify the correct otp is enter
    */
    public function checkOtpExists(){
        $otp = $this->input->post('otp');
        $mobile = $this->input->post('mobile');
        $result = $this->studentmodel->check_otp_exists($mobile, $otp);
        echo json_encode($result);   
    }
    
    /*
    * check the username exits or not
    */
    public function checkUserNameExists() {
        $user_name = $this->input->post('user_name');
        $result = $this->studentmodel->check_user_name_exists($user_name);
        echo json_encode($result);
    }
    
    /*
    * check the email exits or not
    */
    public function checkEmailExists() {
        $email = $this->input->post('email');
        $result = $this->studentmodel->check_email_exists($email);
        echo json_encode($result);
    }
    
    /*
    * update student data
    */
    public function updateDetail(){
        
        $id= $this->uri->segment(3);
        $dataAr = array(
            'first_name' => $this->input->post('first_name'),
            'last_name' => $this->input->post('last_name'),
            'user_name' => $this->input->post('user_name'),
            'email' => $this->input->post('email'),
            'mobile' => $this->input->post('mobile'),
            );
            
        $update = $this->studentmodel->updateStudentData($dataAr,$id);
        if($update){
            redirect('student/editprofile');
            }
    }
    
    /*
    * change password method
    */
    public function change_password(){
        
        
        $oldpassword = $this->input->post('old_password');
        $newpassword = encrypt_script($this->input->post('new_password'));
        $id = $this->input->post('id');
        
        
        $result = $this->studentmodel->updatepassword($id,$newpassword);
        if($result){
            redirect('student/editprofile');
        }
        
    }
    
    
    /*
    * quiz list
    */
    public function quizlist(){
        $data['quizlist'] =  $this->studentmodel->getActiveQuizList();
        $this->load->back_template($this->view_path."quizlist",$data);
    }
    
    /* all quiz with filter*/
    public function getAllQuiz(){
        $data['quiz'] = $this->AdminModel->fetchAllQuiz();
        $data['courses'] = $this->AdminModel->fetchAllCourse();
        $this->load->back_template($this->view_path."all_quiz_list",$data);
    }
    
    /*
    * quiz screen 
    */
    public function quiz_screen(){
        $quizid = $this->uri->segment('3');
        
        $StudentSessionId         = $this->session->userdata['id'];
        $data['QuizTypeId']       = $this->uri->segment('3');
        // $data['existuser'] = $this->college_model->fetch_user_exist($quizid,$StudentSessionId);
        
            if(isset($data['QuizTypeId'])){
                $data['quizinfo'] = $this->studentmodel->getQuizByid($data['QuizTypeId']); 
                }else{
                $data['quizinfo'] =  "Please select the Quiz Type";
            }
            // r($data['quizinfo']);
            // exit();
        $this->load->view('student/quiz_screen',$data);
    }
    
    /*
    * ajax call to set all question
    * of the quiz 
    */
    // public function set_question(){

    //     $quiz_id                  = $this->input->post('quiz_id');
    //     $studentid                = $this->session->userdata['id'];
    //     $total_number_of_question = $this->input->post('total_number_of_question');
    //     // $mark_for_review          = ''

    //     $this->db->select('*');
    //     $this->db->from('questionset');
    //     $this->db->where('quiz_id', $quiz_id );  
    //     $this->db->limit($total_number_of_question);
    //     $this->db->order_by('id','asc');
    //     $query = $this->db->get(); 
        

    //     $total_number_of_question_quiz_id=  $query->result_array();
        
        
    //     $questionset = array();
    //     // shuffle($total_number_of_question_quiz_id);
    //     foreach ($total_number_of_question_quiz_id as  $value) {
            
    //         $questionset[]  =   $value['id'];
    //         $data = array(
    //             'quiz_id'               => $this->input->post('quiz_id'),
    //             'student_id'            => $this->input->post('studentid'),
    //             'qset_id'                  => $value['id'],
    //             'questions_status_id'   => 7
    //             );
    //         $get_question_id = $this->studentmodel->student_insert_question($data, $total_number_of_question);
        
    //     }
        
    //     // student_quiz_result insert
    //     // $dataAr = array(
    //     //     'quiz_id' => $this->input->post('quiz_id'),
    //     //     'student_id' => $this->input->post('studentid'),
    //     //     'attempts' => 1,
    //     //     'quiz_status' => 3,//in-progress
    //     //     'created_at' => date('Y-m-d H:i:s'),,
    //     //     'is_deleted' => 0,
    //     //     'quiz_result' => ''
    //     //     );
    //     // $insertquiz = $this->studentmodel->insertQuizAttempt($dataAr);
        
        
    //     // $arrayQuestionReverse = array_reverse($questionset);
    //     $this->db->select('questionset.* , quiz.id as quizprimaryId, quiz.selected_answer, quiz.mark_for_review');
    //     $this->db->from('questionset', 'quiz');
    //     $this->db->join('quiz', 'quiz.quiz_id = questionset.quiz_id');
    //     // $this->db->where( 'quiz.student_id =',$studentid);
    //     $this->db->where( 'questionset.quiz_id =',$quiz_id);
        
    //     $this->db->limit(1);
    //     $query = $this->db->get();
    //     // echo $this->db->last_query();
    //     $all_question_questionId = $query->result_array();

    //     echo json_encode($all_question_questionId);
       

    // }
      public function set_question(){

        $quiz_id                  = $this->input->post('quiz_id');
        $studentid                = $this->session->userdata['id'];
        $total_number_of_question = $this->input->post('total_number_of_question');
        //$mark_for_review          = 

        $this->db->select('*');
        $this->db->from('questionset');
        $this->db->where('quiz_id', $quiz_id );  
        $this->db->limit($total_number_of_question);
        $query = $this->db->get(); 
        

        $total_number_of_question_quiz_id=  $query->result_array();
        $questionset = array();
        //shuffle($total_number_of_question_quiz_id);
        foreach ($total_number_of_question_quiz_id as  $value) {
         
         $questionset[]  =   $value['id'];


         $data = array(
            'quiz_id'               => $this->input->post('quiz_id'),
            'student_id'            => $this->input->post('studentid'),
            'qset_id'                  => $value['id'],
            'questions_status_id'   => 7,
            'status' => 2//1- completed  , 2- inprogress

         );
        $get_question_id = $this->studentmodel->student_insert_question($data, $total_number_of_question);
        
     }
        // $arrayQuestionReverse = array_reverse($questionset);
       // echo "<pre>";print_r($arrayQuestionReverse);"</pre>";die;
        $this->db->select('questionset.* , quiz.id as quizprimaryId, quiz.selected_answer, quiz.mark_for_review');
        $this->db->from('questionset', 'quiz');
        $this->db->join('quiz', 'quiz.qset_id = questionset.id');
        $this->db->where( 'quiz.qset_id =',$questionset[0]);
        $this->db->where( 'quiz.student_id =',$studentid);
        $this->db->limit(1);
        $query = $this->db->get();
        $all_question_questionId = $query->result_array();

        // echo "<pre>";print_r($this->db->last_query());"</pre>";die;

         echo json_encode($all_question_questionId);
        // echo "<pre>";print_r($this->db->last_query());"</pre>";die;

    }
    
    /*
    * pass the selected answer 
    * to udpate in the quiz given 
    * by student
    */
//     public function questionSequence(){

//         $questionSequence = $this->input->post('questionSequence');
//         $studentid                = $this->session->userdata['id'];

//         $quizid = $this->input->post('quizid');
//         $this->db->select('questionset.* , quiz.id as quizprimaryId');
//         $this->db->from('questionset', 'quiz');
//         $this->db->join('quiz', 'quiz.qset_id = questionset.id','left');
//         $this->db->where('questionset.quiz_id',$quizid);// need to pass the quiz id //remeber
//         // $this->db->where_not_in( 'questionset.id',$questionSequence);
//         $this->db->where('quiz.student_id',$studentid);
//         $this->db->order_by('questionset.id','Asc');
        
//         $query = $this->db->get(); 
//         // echo $this->db->last_query();
//         $result = $query->result_array();
//         // $response = array();
//         // foreach($result as $key => $value){
//         //     // $response[$key] = $value;
//         //     $response[$value->id] = $value;
//         // }
//         // r($response);
//         // array_unshift($result,"");
// // unset($result[0]);
//         $resultrange =range(1, count($result));
//         // r($resultrange);
//         // r(($result));
        
        
//         $FilteredquestionSequence = array_combine($resultrange, array_values($result));
//         // r($FilteredquestionSequence);
//         // r($response[$questionSequence]);
//         //         exit();

//         $FilteredquestionSequence = array_combine($resultrange, array_values($result));
//         echo json_encode( $FilteredquestionSequence[$questionSequence] );    
//         die;
//      //  

//     }
    public function questionSequence(){

        $questionSequence = $this->input->post('questionSequence');
        $studentid                = $this->session->userdata['id'];
                $quizid = $this->input->post('quizid');

        $this->db->select('questionset.* , quiz.id as quizprimaryId');
        $this->db->from('questionset', 'quiz');
        $this->db->join('quiz', 'quiz.qset_id = questionset.id');
        
        $this->db->where('quiz.quiz_id',$quizid);
        $this->db->where('quiz.student_id',$studentid);
        $this->db->order_by('questionset.id','Asc');
        $query = $this->db->get(); 
        // echo $this->db->last_query();
        $result = $query->result_array();
        
        $FilteredquestionSequence = array_combine(range(1, count($result)), array_values($result));
        // r($FilteredquestionSequence[$questionSequence]);
        echo json_encode( $FilteredquestionSequence[$questionSequence] );    
        die;
     //  

    }
    
    /*
    * get the next question of the quiz
    */
    public function get_question_next_and_prev(){

        $quizId          = $this->input->post('quizId');
        $pageId          = $this->input->post('pageId');
        $question_id     = $this->input->post('QuestionId');
        $buttonAction    = $this->input->post('buttonAction');
        $quizPrimaryId   = $this->input->post('quizPrimaryId');
        $submitedAnswer  = $this->input->post('submitedAnswer');
        $StudentSessionId= $this->session->userdata['id']; 
        
        if($buttonAction ==  'redirect'){
             $resultRedirect = $this->studentmodel->get_question_redirect( $question_id,$quizId, $submitedAnswer,$pageId,$quizPrimaryId );
             echo json_encode($resultRedirect);
             die;   
        }    

        if($submitedAnswer != "" ){

            $this->db->select('negative_marks,max_marks,number_of_questions');
            $this->db->from('quiz_master');
            $this->db->where('id' , $quizId );
            $query = $this->db->get();
            $quizeResult = $query->result_array();

            $this->db->select('correct_option');
            $this->db->from('questionset');
            $this->db->where('quiz_id' , $quizId );
            $this->db->where('id' , $question_id );
            $query = $this->db->get();
            // echo $this->db->last_query();
            $result = $query->result_array();

        
            if($result[0]['correct_option'] == $submitedAnswer){

                $questionWiseMarks =   $quizeResult[0]['max_marks'] / $quizeResult[0]['number_of_questions']; 
                $this->db->where('id', $quizPrimaryId);
                // $this->db->where('qset_id', $question_id);
                $this->db->where('quiz_id', $quizId);
                $this->db->where('student_id', $StudentSessionId);
                $this->db->set('selected_answer', $submitedAnswer);
                $this->db->set('marks', $questionWiseMarks);
                $this->db->set('questions_status_id', 5);
                $this->db->update('quiz');   

            }else {

                $this->db->where('id', $quizPrimaryId);
                // $this->db->where('qset_id', $question_id);
                $this->db->where('student_id', $StudentSessionId);
                $this->db->where('quiz_id', $quizId);
                $this->db->set('marks', $quizeResult[0]['negative_marks']);
                $this->db->set('selected_answer', $submitedAnswer);
                $this->db->set('questions_status_id', 9);
                $this->db->update('quiz');
                

            }
             
            $this->db->where('id', $quizPrimaryId);
            // $this->db->where('qset_id', $question_id);
            $this->db->where('student_id', $StudentSessionId);
            $this->db->set('correct_answer', $result[0]['correct_option']);
            $this->db->update('quiz');

        }

        if( $buttonAction == 'next'){
           $result =  $this->studentmodel->get_question_next($question_id,$quizId, $submitedAnswer, $pageId,$quizPrimaryId);
        }else if ($buttonAction == 'prev' ){
            $result = $this->studentmodel->get_question_prev($question_id,$quizId, $submitedAnswer ,$pageId,$quizPrimaryId );
        }else if($buttonAction == 'review'){
             $result = $this->studentmodel->get_question_review($question_id,$quizId, $submitedAnswer,$pageId,$quizPrimaryId );
        }else if($buttonAction == 'unreview'){
             $result = $this->studentmodel->get_question_unreview($question_id,$quizId, $submitedAnswer,$pageId,$quizPrimaryId );
        }else if($buttonAction == 'submit'){
            $result = $this->studentmodel->submit_answer_of_student($pageId,$quizId, $submitedAnswer, $question_id );
        }
        echo json_encode($result);
        die;
    }
    
    /*
    * update 
    */
    public function updateQuestionPalletStatus(){
        $quizPrimaryId  = $this->input->post('quizPrimaryId');
        $getSubmittedStatus = $this->studentmodel->updateQuestionPalletStatus( $quizPrimaryId );
        echo json_encode($getSubmittedStatus);
        die;
    }
    
    public function submitFinalAnswer(){

       // echo "<pre>";print_r($_POST);"</pre>";die;
        
        $quizId          = $this->input->post('quizId');
        $pageId          = $this->input->post('pageId');
        $question_id     = $this->input->post('questionId');
        $quizPrimaryId   = $this->input->post('quizPrimaryId');
        $submitedAnswer  = $this->input->post('submitedAnswer');
        $StudentSessionId= $this->session->userdata['id'];



        if($submitedAnswer != "" ){

            $this->db->select('negative_marks,max_marks,number_of_questions');
            $this->db->from('quiz_master');
            $this->db->where('id' , $quizId );
            $query = $this->db->get();
            $quizeResult = $query->result_array();

    
            $this->db->select('correct_option');
            $this->db->from('questionset');
            $this->db->where('quiz_id' , $quizId );
            $this->db->where('id' , $question_id );
            $query = $this->db->get();
            $result = $query->result_array();
    
            if($result[0]['correct_option'] == $submitedAnswer){

                $questionWiseMarks =   $quizeResult[0]['max_marks'] / $quizeResult[0]['number_of_questions']; 
                $this->db->where('id', $quizPrimaryId);
                $this->db->where('qset_id', $question_id);
                $this->db->where('quiz_id', $quizId);
                $this->db->where('student_id', $StudentSessionId);
                $this->db->set('selected_answer', $submitedAnswer);
                $this->db->set('marks', $questionWiseMarks);
                $this->db->set('questions_status_id', 5);
                $this->db->set('correct_answer', $result[0]['correct_option']);
                $this->db->update('quiz'); 
                // echo $this->db->last_query();

            }else {

                $this->db->where('id', $quizPrimaryId);
                $this->db->where('qset_id', $question_id);
                $this->db->where('student_id',$StudentSessionId );
                $this->db->where('quiz_id', $quizId);
                $this->db->set('marks', $quizeResult[0]['negative_marks']);
                $this->db->set('selected_answer', $submitedAnswer);
                $this->db->set('questions_status_id', 9);
                $this->db->update('quiz');

            }
            
            //get the student attempts from the tb 
            $getstudentatttemt = $this->studentmodel->getStudentAttemptsCount($quizId,$StudentSessionId);
            $getstudentatttemt++;
            
            /* add the result of quiz in table*/
            $dataArr = array(
                'quiz_id' => $quizId,
                'student_id' => $StudentSessionId,
                'attempts' => $getstudentatttemt,
                'quiz_status' => 1,
                'is_deleted' =>'0',
                'created_at' => date('Y-m-d H:i:s'),
                
                );
             
            //   $this->db->where('id', $quizPrimaryId);
                // $this->db->where('qset_id', $question_id);
                $this->db->where('quiz_id', $quizId);
                $this->db->where('student_id', $StudentSessionId);
                $this->db->set('status',1);
                $this->db->update('quiz'); 
              
          //student_quiz_result
            $insertResult = $this->studentmodel->insertQuizResult($dataArr);
            

        }

        $getSubmittedAnswer = $this->studentmodel->submit_answer_of_student($pageId,$quizId, $submitedAnswer, $question_id );
        echo json_encode($getSubmittedAnswer);
        die;
    }

    public function countPendingAnswer(){
        $quizId = $this->input->post('quizId');
       // echo "<pre>";print_r($quizId);"</pre>";die;
        $countPendingAnswer = $this->studentmodel->countPendingAnswer( $quizId );
        echo json_encode($countPendingAnswer);


    }
    
    
    /*
    */
    public function updatetimerCountDownSubmitAnswer(){
        echo "<pre>";print_r($_POST);"</pre>";die;
        $quizId          = $this->input->post('quizId');
        $pageId          = $this->input->post('pageId');
        $question_id     = $this->input->post('questionId');
        $quizPrimaryId   = $this->input->post('quizPrimaryId');
        $submitedAnswer  = $this->input->post('submitedAnswer');
        $StudentSessionId= $this->session->userdata['studentid'];



        if($submitedAnswer != "" ){

            $this->db->select('negative_marks,max_marks,number_of_questions');
            $this->db->from('quiz_master');
            $this->db->where('id' , $quizId );
            $query = $this->db->get();
            $quizeResult = $query->result_array();

            $this->db->select('correct_option');
            $this->db->from('questionset');
            $this->db->where('quiz_id' , $quizId );
            $this->db->where('id' , $question_id );
            $query = $this->db->get();
            $result = $query->result_array();

            if($result[0]['correct_option'] == $submitedAnswer){

                $questionWiseMarks =   $quizeResult[0]['max_marks'] / $quizeResult[0]['number_of_questions']; 
                $this->db->where('id', $quizPrimaryId);
                $this->db->where('qset_id', $question_id);
                $this->db->where('quiz_id', $quizId);
                $this->db->where('student_id', $StudentSessionId);
                $this->db->set('selected_answer', $submitedAnswer);
                $this->db->set('marks', $questionWiseMarks);
                $this->db->set('questions_status_id', 5);
                $this->db->update('quiz');   

            }else {

                $this->db->where('id', $quizPrimaryId);
                $this->db->where('qset_id', $question_id);
                $this->db->where('student_id', $StudentSessionId);
                $this->db->where('quiz_id', $quizId);
                $this->db->set('marks', $quizeResult[0]['negative_marks']);
                $this->db->set('selected_answer', $submitedAnswer);
                $this->db->set('questions_status_id', 9);
                $this->db->update('quiz');

            }
             
            $this->db->where('id', $quizPrimaryId);
            $this->db->where('qset_id', $question_id);
            $this->db->where('student_id', $StudentSessionId);
            $this->db->set('correct_answer', $result[0]['correct_option']);
            $this->db->update('quiz');

        }

        $getSubmittedAnswer = $this->college_model->submit_answer_of_student_timerEndsUp($pageId,$quizId, $submitedAnswer, $question_id );
        echo json_encode($getSubmittedAnswer);
        die;

    }
    
    /*
    * quiz result scrren dispaly
    */
    public function quizresult(){
        $quizId = $this->uri->segment('3');
        $studentid = $this->session->userdata['id'];
        $data['quizresult'] = $this->studentmodel->getQuizResultById($studentid,$quizId);
        $this->load->view('student/result_screen');
    }

    public function countDownTimer(){
        $quizId = $this->input->post('quizId');

        $this->db->select('quiz_total_time');
        $this->db->from('quiz_master');
        $this->db->where('id' , $quizId);
        $query = $this->db->get();
        $result = $query->result_array();
        $duration = "";
            foreach ($result as  $value) {
                $duration = $value;

            }
           $sesionDusration   = $this->session->set_userdata('duration', $duration['quiz_total_time']);
           $sessionStarTime   = $this->session->set_userdata('start_time',date("Y-m-d H:i:s") );
           $end_time          = date('Y-m-d H:i:s' , strtotime('+'.$sesionDusration.'miniutes',strtotime( $sessionStarTime ) ) );
           $sessionEndTime    = $this->session->set_userdata('end_time',$end_time );
          
           $fromTime   = date("Y-m-d H:i:s");
           $toTime     = $this->session->userdata('end_time');

           $convertIntoStrtotimeFromTime = strtotime($fromTime);
           $convertIntoStrtotimeToTime   = strtotime($toTime);

           $difernceInSecond             = $convertIntoStrtotimeToTime - $convertIntoStrtotimeFromTime;

           $timer = gmdate("i:s" , $difernceInSecond );

          // echo "<pre>";print_r($timer);"</pre>";die; 
           echo json_encode($timer);  
           die;



    }

    
    /*
    * student logout
    */
    public function student_logout(){
        $this->session->sess_destroy();
        $this->session->set_userdata('is_student_loggedin', false);
        redirect('student/login');
    }
    
}
